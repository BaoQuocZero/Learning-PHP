<?php include 'header.php'; ?>
<h1 align="center">ĐĂNG NHẬP QUẢN TRỊ</h1>
<form action="xly_dangnhapad.php" name="dangnhap" method="post">

<table align="center" border="0">
<tr><td>
Tên đăng nhập:</td><td> <input type="text" name="tendn" /></td></tr>
<tr><td>Mật khẩu:</td><td><input type="password" name="matkhau" /> </td></tr>
<tr>
<td><input style="color:#FF3366;" type="submit" name="dn" value="Đăng nhập"/></td>
<td align="center"><input style="color:#FF3366;" type="reset" name="ll" value="Làm lại" /></td>
</tr>
</table>
</form>
