<?php
$kn=mysqli_connect("localhost","root",""); 
$csdl=mysqli_select_db($kn, "online_shop");
mysqli_query($kn, "SET NAMES 'utf8'");
?>